# How to Hack Like a Ghost
This repository hosts scripts and techniques featured in the book [How to Hack Like a Legend](https://nostarch.com/how-hack-legend)
