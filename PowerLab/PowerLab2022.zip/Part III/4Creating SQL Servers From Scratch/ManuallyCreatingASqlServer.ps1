New-PowerLabVm -Name 'SQLSRV'
Install-PowerLabOperatingSystem -VmName 'SQLSRV'
Start-VM -Name SQLSRV

Get-Credential | Export-CliXml -Path d:\PowerLab\LabCredentialSQL.xml
$vmCred = Import-CliXml -Path 'D:\PowerLab\LabCredentialSQL.xml'

while (-not (Invoke-Command -VmName SQLSRV -ScriptBlock { 1 } -Credential $vmCred -ErrorAction Ignore)) {
	Start-Sleep -Seconds 10
	Write-Host 'Waiting for SQLSRV to come up...'
}

Get-Credential | Export-CliXml -Path d:\PowerLab\LabCredentialAdmin.xml
$vmCred = Import-CliXml -Path 'D:\PowerLab\LabCredentialAdmin.xml'
Invoke-Command -VMName SQLSRV -ScriptBlock { hostname } -Credential $vmCred

$domainCred = Import-CliXml -Path 'D:\PowerLab\LabCredential.xml'
$addParams = @{
	DomainName = 'powerlab.local'
	Credential = $domainCred
	Restart    = $true
	Force      = $true
}
Invoke-Command -VMName SQLSRV -ScriptBlock { Add-Computer @using:addParams } -Credential $vmCred

# wait as vmCred
while (Invoke-Command -VmName SQLSRV -ScriptBlock { 1 } -Credential $vmCred -ErrorAction Ignore) {
	Start-Sleep -Seconds 10
	Write-Host 'Waiting for SQLSRV to go down...'
}

# wait as domainCred
while (-not (Invoke-Command -VmName SQLSRV -ScriptBlock { 1 } -Credential $domainCred -ErrorAction Ignore)) {
	Start-Sleep -Seconds 10
	Write-Host 'Waiting for SQLSRV to come up...'
}

$session = New-PSSession -VMName 'SQLSRV' -Credential $domainCred
$sqlServerAnswerFilePath = "C:\Program Files\WindowsPowerShell\Modules\PowerLab\SqlServer.ini"
$tempFile = Copy-Item -Path $sqlServerAnswerFilePath -Destination "C:\Program Files\WindowsPowerShell\Modules\PowerLab\temp.ini" -PassThru

$configContents = Get-Content -Path $tempFile.FullName -Raw
$configContents = $configContents.Replace('SQLSVCACCOUNT=""', 'SQLSVCACCOUNT="PowerLabUser"')
$configContents = $configContents.Replace('SQLSVCPASSWORD=""', 'SQLSVCPASSWORD="P@$$w0rd12"')
$configContents = $configContents.Replace('SQLSYSADMINACCOUNTS=""', 'SQLSYSADMINACCOUNTS="PowerLabUser"')
Set-Content -Path $tempFile.FullName -Value $configContents

# New-Item -Path 'C:\tmp' -ItemType Directory

$copyParams = @{
	Path        = $tempFile.FullName
	Destination = 'C:\tmp'
	ToSession   = $session
}
Copy-Item @copyParams

Remove-Item -Path $tempFile.FullName -ErrorAction Ignore
Copy-Item -Path 'd:\ISO\SW_DVD9_NTRL_SQL_Svr_Standard_Edtn_2016_64Bit_English_OEM_VL_X20-97264.ISO' -Destination 'C:\tmp' -Force -ToSession $session

# Do it for 'sqlsrv\powerlabuser' once!
Get-Credential | Export-CliXml -Path d:\PowerLab\LabCredentialSQL2.xml

$vmCred = Import-CliXml -Path 'D:\PowerLab\LabCredentialSQL2.xml'
$session = New-PSSession -VMName 'SQLSRV' -Credential $vmCred
Invoke-Command -ScriptBlock { hostname } -Session $session

# whoami
# icacls C:\tmp /setintegritylevel medium
# takeown /f c:\tmp /r /d y
# icacls C:\tmp /grant PowerLabUser:F /t /c /l /q

$icmParams = @{
	Session      = $session
	ArgumentList = $tempFile.Name
	ScriptBlock  = {
		$image = Mount-DiskImage -ImagePath 'C:\tmp\SW_DVD9_NTRL_SQL_Svr_Standard_Edtn_2016_64Bit_English_OEM_VL_X20-97264.ISO' -PassThru
		$installerPath = "$(($image | Get-Volume).DriveLetter):"
		$null = & "$installerPath\setup.exe" "/CONFIGURATIONFILE=C:\tmp\$($using:tempFile.Name)"
		$image | Dismount-DiskImage
	}
}
Invoke-Command @icmParams

Invoke-Command -Session $session -ScriptBlock { Get-Service -Name 'MSSQLSERVER' -ErrorAction Ignore }
Invoke-Command -Session $session -ScriptBlock { Get-CimInstance -Class Win32_Service -Filter 'Name = "MSSQLSERVER"' | Select StartName | fl}
 
$scriptBlock = { Remove-Item -Path 'C:\tmp\SW_DVD9_NTRL_SQL_Svr_Standard_Edtn_2016_64Bit_English_OEM_VL_X20-97264.ISO', "C:\tmp\$($using:tempFile.Name)" -Recurse -ErrorAction Ignore }
Invoke-Command -ScriptBlock $scriptBlock -Session $session

$session | Remove-PSSession