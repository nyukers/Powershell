describe 'Creating and Configuring SQL Servers Prerequisites' {

	$vmName = 'LABDC'

	it 'has a VM called LABDC setup' {
		Get-Vm -Name $vmName | should not benullorEmpty
	}

	it 'LABDC must be running' {
		(Get-VM -Name $vmName).State | should be 'Running'
	}

	it 'must have a domain credential stored locally' {
		'd:\PowerLab\LabCredential.xml' | should exist
	}

	it 'LABDC must be a domain controller' {
		$icmParams = @{
			VMName      = $vmName
			Credential  = (Import-CliXml -path 'd:\PowerLab\LabCredential.xml')
			ScriptBlock = { (Get-AddomainController).Name }
		}
		Invoke-Command @icmParams | should be $vmName
	}

	it 'the PowerLab module must be installed' {
		'C:\Program Files\WindowsPowerShell\Modules\PowerLab\PowerLab.psm1' | should exist
	}

	it 'the SQLServer.ini answer file template must exist' {
		'C:\Program Files\WindowsPowerShell\Modules\PowerLab\SQLServer.ini' | should exist
	}

	it 'the SQL server 2016 ISO file must exist' {
		'D:\ISO\SW_DVD9_NTRL_SQL_Svr_Standard_Edtn_2016_64Bit_English_OEM_VL_X20-97264.ISO' | should exist
	}
}