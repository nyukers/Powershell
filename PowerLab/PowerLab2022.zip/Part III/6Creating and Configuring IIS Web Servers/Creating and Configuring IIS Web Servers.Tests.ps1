describe 'WEBSRV' {

	BeforeAll {
		$domainCred = Import-Clixml -Path d:\PowerLab\LabCredentialWeb.xml
		$session = New-PSSession -VMName 'WEBSRV' -Credential $domainCred
	}

	AfterAll {
		$session | Remove-PSSession
	}

	context 'IIS installation' {

		it 'The Web-Server feature is enabled' {
			Invoke-Command -Session $session -ScriptBlock { (Get-WindowsFeature -Name 'Web-Server').Installed } | should be $true
		}
	}

	context 'IIS configuration' {

		it 'a website called PowerShellForSysAdmins exists' {
			Invoke-Command -Session $session -ScriptBlock { Get-WebSite -Name PowerShellForSysAdmins } | should not benullorempty
		}

		it 'the PowerShellForSysAdmins website has an SSL binding setup' {
			$bindings = Invoke-Command -Session $session -ScriptBlock { (Get-Website -Name PowerShellForSysAdmins).bindings.Collection }
			$bindings.protocol | should be 'https'
			$bindings.bindingInformation | should be '*:443:*'
			
		}
	}
}