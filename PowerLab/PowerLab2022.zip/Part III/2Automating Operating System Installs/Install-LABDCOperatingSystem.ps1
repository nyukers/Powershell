$isoFilePath = 'd:\ISO\SW_DVD9_Win_Svr_STD_Core_and_DataCtr_Core_2016_64Bit_Russian_-3_MLF_X21-30363.ISO'

$answerFilePath = 'C:\Program Files\WindowsPowerShell\Modules\PowerLab\LABDC.xml'


$convertParams = @{
    SourcePath        = $isoFilePath
    SizeBytes         = 40GB
    Edition           = 'ServerStandardCore'
    VHDFormat         = 'VHDX'
    VHDPath           = 'D:\PowerLab\VHDs\LABDC.vhdx'
    VHDType           = 'Dynamic'
    VHDPartitionStyle = 'GPT'
    UnattendPath      = $answerFilePath
}

. 'C:\Program Files\WindowsPowerShell\Modules\PowerLab\Convert-WindowsImage.ps1'

#.'C:\Program Files\WindowsPowerShell\Modules\PowerLab\Convert-WindowsImage.ps1' -ShowUI

Convert-WindowsImage @convertParams

$vm = Get-Vm -Name 'LABDC'
$vm | Add-VMHardDiskDrive -Path 'd:\PowerLab\VHDs\LABDC.vhdx'
$bootOrder = ($vm | Get-VMFirmware).Bootorder
if ($bootOrder[0].BootType -ne 'Drive') {
    $vm | Set-VMFirmware -FirstBootDevice $vm.HardDrives[0]
}