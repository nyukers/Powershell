describe 'Automating Operating System Install Prerequisites' {

	$isosPath = 'd:\ISO'
	$windowsIsoPath = "$isosPath\SW_DVD9_WIN_SERVER_STD_CORE_2019_1909.4_64BIT_ENGLISH_DC_STD_MLF_X22-29333.ISO"
	$convertWimImageScriptPath = 'C:\Program Files\WindowsPowerShell\Modules\PowerLab\Convert-WindowsImage.ps1'
	$vmName = 'LABDC'

	it 'has an ISOs folder created' {
		$isosPath | should exist
	}
	
	it 'has the Windows ISO available' {
		$windowsIsoPath | should exist
	}

	it 'has the Convert-WindowsImage.ps1 PowerShell script available' {
		$convertWimImageScriptPath | should exist
	}

	it 'has an existing VM setup' {
		Get-Vm -Name $vmName | should not benullorEmpty
	}

	it 'has the unattended XML file in the right spot' {
        'C:\Program Files\WindowsPowerShell\Modules\PowerLab\LABDC.xml' | should exist
	}
}