﻿namespace PowerForensics.Windows.Registry
{
    /// <summary>
    /// 
    /// </summary>
    public class OffsetRecord
    {
        #region Properties

        /// <summary>
        /// 
        /// </summary>
        public readonly uint RelativeOffset;

        /// <summary>
        /// 
        /// </summary>
        public readonly uint Hash;

        #endregion Properties
    }
}
