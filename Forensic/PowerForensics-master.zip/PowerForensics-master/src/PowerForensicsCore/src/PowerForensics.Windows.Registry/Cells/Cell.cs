﻿namespace PowerForensics.Windows.Registry
{
    /// <summary>
    /// 
    /// </summary>
    public class Cell
    {
        #region Properties

        internal int Size;

        /// <summary>
        /// 
        /// </summary>
        public bool Allocated;

        internal string Signature;

        #endregion Properties
    }
}