# Get-ForensicMasterBootRecord

## SYNOPSIS
Gets the Master Boot Record for the specified physical drive.

## SYNTAX

```
Get-ForensicMasterBootRecord [-Path] <String> [-AsBytes]
```

## DESCRIPTION
The Get-ForensicMasterBootRecord cmdlet gets the Master Boot Record for the specified physical drive and analyzes the MBR's boot code for anomalies.

By default, Get-ForensicMasterBootRecord returns a MasterBootRecord object that has detailed information about the drive&apos;s boot code and partition table. You can also use the AsBytes switch parameter to return the raw bytes of the Master Boot Record.

Except as noted, the cmdlets in the PowerForensics module require the permissions of a member of the Administrators group on the computer. To run them, start Windows PowerShell with the 'Run as administrator' option.

## EXAMPLES

### Example 1
```
[ADMIN]: PS C:\> Get-MasterBootRecord -Path \\.\PHYSICALDRIVE0

MBRSignature   DiskSignature   PartitionTable
------------   -------------   --------------
Windows 6.1+   82D4BA7D        {NTFS}
```

This is an example of Get-MasterBootRecord being run against \\.\PHYSICALDRIVE0

### Example 2
```
[ADMIN]: PS C:\> Get-MasterBootRecord -Path \\.\PHYSICALDRIVE0 -AsBytes | Format-Hex

Offset     _00_01_02_03_04_05_06_07_08_09_0A_0B_0C_0D_0E_0F  Ascii
------     ------------------------------------------------  -----
0x00000000  33 C0 8E D0 BC 00 7C 8E C0 8E D8 BE 00 7C BF 00  3.....|......|..
0x00000010  06 B9 00 02 FC F3 A4 50 68 1C 06 CB FB B9 04 00  .......Ph.......
0x00000020  BD BE 07 80 7E 00 00 7C 0B 0F 85 0E 01 83 C5 10  ....~..|........
0x00000030  E2 F1 CD 18 88 56 00 55 C6 46 11 05 C6 46 10 00  .....V.U.F...F..
0x00000040  B4 41 BB AA 55 CD 13 5D 72 0F 81 FB 55 AA 75 09  .A..U..]r...U.u.
0x00000050  F7 C1 01 00 74 03 FE 46 10 66 60 80 7E 10 00 74  ....t..F.f`.~..t
0x00000060  26 66 68 00 00 00 00 66 FF 76 08 68 00 00 68 00  &amp;fh....f.v.h..h.
0x00000070  7C 68 01 00 68 10 00 B4 42 8A 56 00 8B F4 CD 13  |h..h...B.V.....
0x00000080  9F 83 C4 10 9E EB 14 B8 01 02 BB 00 7C 8A 56 00  ............|.V.
0x00000090  8A 76 01 8A 4E 02 8A 6E 03 CD 13 66 61 73 1C FE  .v..N..n...fas..
0x000000A0  4E 11 75 0C 80 7E 00 80 0F 84 8A 00 B2 80 EB 84  N.u..~..........
0x000000B0  55 32 E4 8A 56 00 CD 13 5D EB 9E 81 3E FE 7D 55  U2..V...]...&gt;.}U
0x000000C0  AA 75 6E FF 76 00 E8 8D 00 75 17 FA B0 D1 E6 64  .un.v....u.....d
0x000000D0  E8 83 00 B0 DF E6 60 E8 7C 00 B0 FF E6 64 E8 75  ......`.|....d.u
0x000000E0  00 FB B8 00 BB CD 1A 66 23 C0 75 3B 66 81 FB 54  .......f#.u;f..T
0x000000F0  43 50 41 75 32 81 F9 02 01 72 2C 66 68 07 BB 00  CPAu2....r,fh...
0x00000100  00 66 68 00 02 00 00 66 68 08 00 00 00 66 53 66  .fh....fh....fSf
0x00000110  53 66 55 66 68 00 00 00 00 66 68 00 7C 00 00 66  SfUfh....fh.|..f
0x00000120  61 68 00 00 07 CD 1A 5A 32 F6 EA 00 7C 00 00 CD  ah.....Z2...|...
0x00000130  18 A0 B7 07 EB 08 A0 B6 07 EB 03 A0 B5 07 32 E4  ..............2.
0x00000140  05 00 07 8B F0 AC 3C 00 74 09 BB 07 00 B4 0E CD  ......&lt;.t.......
0x00000150  10 EB F2 F4 EB FD 2B C9 E4 64 EB 00 24 02 E0 F8  ......+..d..$...
0x00000160  24 02 C3 49 6E 76 61 6C 69 64 20 70 61 72 74 69  $..Invalid parti
0x00000170  74 69 6F 6E 20 74 61 62 6C 65 00 45 72 72 6F 72  tion table.Error
0x00000180  20 6C 6F 61 64 69 6E 67 20 6F 70 65 72 61 74 69   loading operati
0x00000190  6E 67 20 73 79 73 74 65 6D 00 4D 69 73 73 69 6E  ng system.Missin
0x000001A0  67 20 6F 70 65 72 61 74 69 6E 67 20 73 79 73 74  g operating syst
0x000001B0  65 6D 00 00 00 63 7B 9A 82 D4 BA 7D 00 00 80 20  em...c{....}...
0x000001C0  21 00 07 FE FF FF 00 08 00 00 00 F0 7F 07 00 00  !...............
0x000001D0  00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  ................
0x000001E0  00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  ................
0x000001F0  00 00 00 00 00 00 00 00 00 00 00 00 00 00 55 AA  ..............U.
```

This command uses the AsBytes parameter of Get-MasterBootRecord to get the MBR as a byte array.

## PARAMETERS

### -AsBytes
Returns Master Boot Record as byte array instead of as MasterBootRecord object.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: 

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Path
Specified the physical drive to investigate. (Ex. \\.\PHYSICALDRIVE0)

```yaml
Type: String
Parameter Sets: (All)
Aliases: DrivePath

Required: True
Position: 0
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

## INPUTS

### None


## OUTPUTS

### PowerForensics.MasterBootRecord

### System.Byte

## NOTES

## RELATED LINKS

