# Get Involved with PowerForensics
Are you interested in contributing to PowerForensics? 
Maybe you are a user and have questions about functionality or have an idea for a new feature. 
Whatever your interest, join the PowerForensics Slack channel and share your ideas with us!

To join, request an invite through our heroku app by visiting <a href="https://powerforensicsslack.herokuapp.com/">https://powerforensicsslack.herokuapp.com/</a> and entering your email address.

<p align="center">
  <img src="https://github.com/Invoke-IR/PowerForensics/blob/master/docs/img/herokuapp.PNG" width="500">
</p>