﻿


# FileSystems.HFSPlus.CatalogThread

## Fields

### ParentId

### NodeName
