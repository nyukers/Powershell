﻿


# Windows.EventLog.FILEFLAGS

## Fields

### IsDirty

### IsFull
