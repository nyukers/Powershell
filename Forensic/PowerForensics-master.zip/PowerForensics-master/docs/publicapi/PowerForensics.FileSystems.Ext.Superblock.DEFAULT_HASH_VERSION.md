﻿


# FileSystems.Ext.Superblock.DEFAULT_HASH_VERSION

## Fields

### Legacy

### HalfMD4

### Tea

### UnsignedLegacy

### UnsignedHalfMD4

### UnsignedTea
