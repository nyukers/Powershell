﻿


# FileSystems.Ntfs.FILE_RECORD_FLAG

## Fields

### INUSE
File record is in use
### DIR
File record is a directory