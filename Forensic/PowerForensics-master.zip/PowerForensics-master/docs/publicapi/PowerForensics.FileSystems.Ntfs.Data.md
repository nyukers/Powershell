﻿


# FileSystems.Ntfs.Data

## Fields

### RawData
