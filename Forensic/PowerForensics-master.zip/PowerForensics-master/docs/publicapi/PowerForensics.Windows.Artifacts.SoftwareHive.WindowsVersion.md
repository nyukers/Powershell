﻿


# Windows.Artifacts.SoftwareHive.WindowsVersion

## Fields

### ProductName

### CurrentMajorVersion

### CurrentMinorVersion

### CurrentVersion

### InstallTime

### RegisteredOwner

### SystemRoot

## Methods


### Get(System.String)

> #### Parameters
> **volume:** 

> #### Return value
> 

### GetByPath(System.String)

> #### Parameters
> **hivePath:** 

> #### Return value
> 