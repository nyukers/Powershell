﻿


# Windows.Artifacts.DarwinDataBlock

## Fields

### DarwinDataAnsi

### DarwinDataUnicode
