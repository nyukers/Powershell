﻿


# FileSystems.Ext.Superblock.STATE

## Fields

### CleanlyUmounted

### ErrorsDetected

### RecoveringOrphans
