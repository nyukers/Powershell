﻿


# FileSystems.HFSPlus.BTree.DataRecord.RECORD_FLAGS

## Fields

### kHFSFileLockedBit

### kHFSFileLockedMask

### kHFSThreadExistsBit

### kHFSThreadExistsMask
