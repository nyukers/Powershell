﻿


# FileSystems.Ntfs.StandardInformation
