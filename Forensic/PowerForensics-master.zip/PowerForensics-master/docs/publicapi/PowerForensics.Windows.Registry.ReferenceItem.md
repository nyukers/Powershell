﻿


# Windows.Registry.ReferenceItem
