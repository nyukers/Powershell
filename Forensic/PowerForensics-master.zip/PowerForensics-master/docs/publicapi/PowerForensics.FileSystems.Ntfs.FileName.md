﻿


# FileSystems.Ntfs.FileName

## Fields

### Filename

### ParentSequenceNumber

### ParentRecordNumber

### Namespace

### AllocatedSize

### RealSize

### Flags

### ER

### ModifiedTime

### AccessedTime

### ChangedTime

### BornTime
