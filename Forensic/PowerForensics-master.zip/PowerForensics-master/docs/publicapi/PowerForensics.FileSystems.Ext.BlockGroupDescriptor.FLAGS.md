﻿


# FileSystems.Ext.BlockGroupDescriptor.FLAGS

## Fields

### EXT4_BG_INODE_UNINIT

### EXT4_BG_BLOCK_UNINIT

### EXT4_BG_INODE_ZEROED
