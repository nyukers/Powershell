﻿


# Windows.Artifacts.ExtraData.EXTRA_DATA_TYPE

## Fields

### EnvironmentVariableDataBlock

### ConsoleDataBlock

### TrackerDataBlock

### ConsoleFeDataBlock

### SpecialFolderDataBlock

### DarwinDataBlock

### IconEnvironmentDataBlock

### ShimDataBlock

### PropertyStoreDataBlock

### KnownFolderDataBlock

### VistaAndAboveIDListDataBlock
