﻿


# Windows.Artifacts.ConsoleDataBlock
