﻿


# FileSystems.HFSPlus.BTree.Node

## Fields

### VolumeName

### FileName

### NodeNumber

### NodeDescriptor

### Records

## Methods


### Get(System.String,System.String,System.UInt32)

> #### Parameters
> **volumeName:** 

> **fileName:** 

> **nodeNumber:** 

> #### Return value
> 

### Get(System.Byte[],System.String,System.String,System.UInt32)

> #### Parameters
> **bytes:** 

> **volumeName:** 

> **fileName:** 

> **nodeNumber:** 

> #### Return value
> 

### GetHeaderNode(System.String,System.String)

> #### Parameters
> **volumeName:** 

> **fileName:** 

> #### Return value
> 

### GetHeaderBytes(System.String,System.String)

> #### Parameters
> **volumeName:** 

> **fileName:** 

> #### Return value
> 

### GetBytes(System.String,System.String,System.UInt32)

> #### Parameters
> **volumeName:** 

> **fileName:** 

> **nodeNumber:** 

> #### Return value
> 