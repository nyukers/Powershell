﻿


# Windows.Artifacts.IconEnvironmentDataBlock

## Fields

### TargetAnsi

### TargetUnicode
