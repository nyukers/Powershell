﻿


# FileSystems.HFSPlus.BSDInfo.FILE_MODE

## Fields

### S_ISTXT

### S_ISGID

### S_ISUID

### S_IXUSR

### S_IWUSR

### S_IRUSR

### S_IRWXU

### S_IXGRP

### S_IWGRP

### S_IRGRP

### S_IRWXG

### S_IXOTH

### S_IWOTH

### S_IROTH

### S_IRWXO

### S_IFIFO

### S_IFCHR

### S_IFDIR

### S_IFBLK

### S_IFREG

### S_IFLNK

### S_IFSOCK

### S_IFWHT

### S_IFMT
