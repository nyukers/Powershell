﻿


# FileSystems.Fat.LongDirectoryEntry
