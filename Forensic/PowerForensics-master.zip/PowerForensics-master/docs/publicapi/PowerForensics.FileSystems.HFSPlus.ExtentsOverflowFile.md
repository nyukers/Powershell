﻿


# FileSystems.HFSPlus.ExtentsOverflowFile

## Methods


### GetContent(System.String)
Returns the contents of the HFS+ Extents Overflow File.
> #### Parameters
> **volumeName:** 

> #### Return value
> 

### GetHeaderNode(System.String)

> #### Parameters
> **volumeName:** 

> #### Return value
> 

### GetNode(System.String,System.UInt32)

> #### Parameters
> **volumeName:** 

> **nodeNumber:** 

> #### Return value
> 

### GetNodeBytes(System.String,System.UInt32)

> #### Parameters
> **volumeName:** 

> **nodeNumber:** 

> #### Return value
> 