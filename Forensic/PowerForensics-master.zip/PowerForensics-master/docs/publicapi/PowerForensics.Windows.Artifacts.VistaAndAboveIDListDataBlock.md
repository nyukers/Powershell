﻿


# Windows.Artifacts.VistaAndAboveIDListDataBlock

## Fields

### IdList
