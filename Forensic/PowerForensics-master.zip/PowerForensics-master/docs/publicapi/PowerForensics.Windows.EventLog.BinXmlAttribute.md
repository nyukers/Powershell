﻿


# Windows.EventLog.BinXmlAttribute

## Fields

### Token

### AttributeNameOffset

### Name
