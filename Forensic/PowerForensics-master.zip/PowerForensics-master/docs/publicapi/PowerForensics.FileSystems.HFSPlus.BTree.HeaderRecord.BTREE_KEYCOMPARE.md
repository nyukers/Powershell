﻿


# FileSystems.HFSPlus.BTree.HeaderRecord.BTREE_KEYCOMPARE

## Fields

### kHFSBinaryCompare

### kHFSCaseFolding
