﻿


# Windows.Registry.RegistryHeader

## Fields

### Signature

### PrimarySequenceNumber

### SecondarySequenceNumber

### ModificationTime

### Version

### FileType

### RootKeyOffset

### HiveBinsDataSize

### HivePath

### Checksum

## Methods


### GetBytes(System.String)

> #### Parameters
> **path:** 

> #### Return value
> 

### Get(System.String)

> #### Parameters
> **path:** 

> #### Return value
> 