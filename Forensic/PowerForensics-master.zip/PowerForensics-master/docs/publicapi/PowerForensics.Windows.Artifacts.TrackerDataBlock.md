﻿


# Windows.Artifacts.TrackerDataBlock

## Fields

### Version

### MachineId

### Droid

### DroidBirth
