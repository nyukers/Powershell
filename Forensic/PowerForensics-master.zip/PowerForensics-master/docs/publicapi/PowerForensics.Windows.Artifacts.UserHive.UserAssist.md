﻿


# Windows.Artifacts.UserHive.UserAssist

## Fields

### User

### ImagePath

### RunCount

### FocusTime

### LastExecutionTimeUtc

## Methods


### Constructor

> #### Parameters
> **user:** 

> **vk:** 

> **bytes:** 


### Get(System.String)

> #### Parameters
> **hivePath:** 

> #### Return value
> 

### GetInstances(System.String)

> #### Parameters
> **volume:** 

> #### Return value
> 

### ToString

> #### Return value
> 