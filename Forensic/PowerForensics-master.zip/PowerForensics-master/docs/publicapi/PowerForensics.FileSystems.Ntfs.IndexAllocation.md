﻿


# FileSystems.Ntfs.IndexAllocation

## Fields

### Entries
