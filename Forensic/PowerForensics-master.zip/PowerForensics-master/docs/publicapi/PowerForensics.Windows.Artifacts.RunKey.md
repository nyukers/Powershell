﻿


# Windows.Artifacts.RunKey

## Fields

### AutoRunLocation

### Name

### ImagePath

## Methods


### GetInstances(System.String)

> #### Parameters
> **volume:** 

> #### Return value
> 

### Get(System.String)

> #### Parameters
> **hivePath:** 

> #### Return value
> 