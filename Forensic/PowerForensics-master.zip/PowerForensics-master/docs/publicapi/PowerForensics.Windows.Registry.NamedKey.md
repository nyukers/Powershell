﻿


# Windows.Registry.NamedKey
