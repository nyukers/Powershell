﻿


# FileSystems.HFSPlus.BTree.KeyedRecord

## Fields

### ParentCatalogNodeId

### Name
