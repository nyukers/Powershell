﻿


# Windows.Artifacts.ScheduledJob.PRODUCT_VERSION

## Fields

### WindowsNT4

### Windows2000

### WindowsXP

### WindowsVista

### Windows7

### Windows8

### Windows8_1
