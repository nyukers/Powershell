﻿


# FileSystems.HFSPlus.Point

## Fields

### Vertical

### Horizontal
