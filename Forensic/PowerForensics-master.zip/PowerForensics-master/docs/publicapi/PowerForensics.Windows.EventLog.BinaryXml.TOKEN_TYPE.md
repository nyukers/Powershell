﻿


# Windows.EventLog.BinaryXml.TOKEN_TYPE

## Fields

### BinXmlTokenEOF

### BinXmlTokenOpenStartElementTag

### BinXmlTokenCloseStartElementTag

### BinXmlTokenCloseEmptyElementTag

### BinXmlTokenEndElementTag

### BinXmlTokenValue

### BinXmlTokenAttribute

### BinXmlTokenCDATASection

### BinXmlTokenCharRef

### BinXmlTokenEntityRef

### BinXmlTokenPITarget

### BinXmlTokenPIData

### BinXmlTokenTemplateInstance

### BinXmlTokenNormalSubstitution

### BinXmlTokenOptionalSubstitution

### BinXmlFragmentHeaderToken

### BinXmlTokenOpenStartElementTag_AttributeList

### BinXmlTokenAttribute_Additional
