﻿


# FileSystems.HFSPlus.FolderInfo

## Fields

### WindowBounds

### FinderFlags

### Location
