﻿


# Windows.Artifacts.Prefetch.PREFETCH_ENABLED

## Fields

### DISABLED

### APPLICATION

### BOOT

### APPLICATION_BOOT
