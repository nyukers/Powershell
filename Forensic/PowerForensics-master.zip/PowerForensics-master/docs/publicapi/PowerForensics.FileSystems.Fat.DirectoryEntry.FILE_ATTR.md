﻿


# FileSystems.Fat.DirectoryEntry.FILE_ATTR

## Fields

### ATTR_READ_ONLY

### ATTR_HIDDEN

### ATTR_SYSTEM

### ATTR_VOLUME_ID

### ATTR_DIRECTORY

### ATTR_ARCHIVE

### ATTR_LONG_NAME
