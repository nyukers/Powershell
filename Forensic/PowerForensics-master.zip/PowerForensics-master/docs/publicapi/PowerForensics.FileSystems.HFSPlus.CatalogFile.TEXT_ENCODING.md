﻿


# FileSystems.HFSPlus.CatalogFile.TEXT_ENCODING

## Fields

### MacRoman

### MacJapanese

### MacChineseTrad

### MacKorean

### MacArabic

### MacHebrew

### MacGreek

### MacCyrillic

### MacDevanagari

### MacGurmukhi

### MacGujarati

### MacOriya

### MacBengali

### MacTamil

### MacTelugu

### MacKannada

### MacMalayalam

### MacSinhales

### MacBurmese

### MacKhmer

### MacThai

### MacLaotian

### MacGeorgian

### MacArmenian

### MacChineseSimp

### MacTibetan

### MacMongolian

### MacEthiopic

### MacCentralEurRoman

### MacVietnamese

### MacExtArabic

### MacSymbol

### MacDingbats

### MacTurkish

### MacCroatian

### MacIcelandic

### MacRomanian

### MacUkrainian

### MacFarsi
