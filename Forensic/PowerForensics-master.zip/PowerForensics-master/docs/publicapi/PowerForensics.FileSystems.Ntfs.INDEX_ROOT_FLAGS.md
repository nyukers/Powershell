﻿


# FileSystems.Ntfs.INDEX_ROOT_FLAGS

## Fields

### INDEX_ROOT_ONLY

### INDEX_ALLOCATION
