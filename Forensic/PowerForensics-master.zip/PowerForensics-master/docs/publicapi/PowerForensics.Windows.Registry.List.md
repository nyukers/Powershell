﻿


# Windows.Registry.List

## Fields

### Size

### Signature

### Allocated

### Count

### Offset
