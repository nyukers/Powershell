﻿


# FileSystems.Ntfs.VolumeInformation.ATTR_VOLINFO

## Fields

### FLAG_DIRTY
Dirty
### FLAG_RLF
Resize logfile
### FLAG_UOM
Upgrade on mount
### FLAG_MONT
Mounted on NT4
### FLAG_DUSN
Delete USN underway
### FLAG_ROI
Repair object Ids
### FLAG_MBC
Modified by chkdsk