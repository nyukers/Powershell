﻿


# Windows.EventLog.BinXmlName

## Fields

### NameSize

### Name

## Methods


### ToString

> #### Return value
> 