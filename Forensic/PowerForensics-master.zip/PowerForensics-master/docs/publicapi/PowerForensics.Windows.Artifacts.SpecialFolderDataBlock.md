﻿


# Windows.Artifacts.SpecialFolderDataBlock

## Fields

### SpecialFolderId

### Offset
