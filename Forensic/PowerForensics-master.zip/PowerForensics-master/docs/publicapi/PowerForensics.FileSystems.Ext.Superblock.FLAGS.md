﻿


# FileSystems.Ext.Superblock.FLAGS

## Fields

### SignedDirectoryHash

### UnsignedDirectoryHash

### DevelopmentCode
