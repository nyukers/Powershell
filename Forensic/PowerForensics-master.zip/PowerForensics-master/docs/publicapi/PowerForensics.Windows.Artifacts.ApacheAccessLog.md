﻿


# Windows.Artifacts.ApacheAccessLog

## Fields

### RemoteHostname

### RemoteLogname

### RemoteUsername

### Timestamp

### HttpMethod

### Request

### Status

### ResponseSize

### Referer

### UserAgent

## Methods


### Get(System.String)

> #### Parameters
> **entry:** 

> #### Return value
> 

### GetInstances(System.String)

> #### Parameters
> **Path:** 

> #### Return value
> 