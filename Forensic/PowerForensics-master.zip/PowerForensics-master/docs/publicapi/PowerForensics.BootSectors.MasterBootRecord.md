﻿


# BootSectors.MasterBootRecord

## Fields

### DiskSignature

### CodeSection

### MbrSignature

### PartitionTable

## Methods


### GetBytes(System.String)

> #### Parameters
> **drivePath:** 

> #### Return value
> 

### Get(System.String)

> #### Parameters
> **drivePath:** 

> #### Return value
> 

### GetPartitions(System.Byte[],System.UInt32,System.String)

> #### Parameters
> **bytes:** 

> **startSector:** 

> **drivePath:** 

> #### Return value
> 

### GetExtended(PowerForensics.BootSectors.PartitionEntry,System.String)

> #### Parameters
> **entry:** 

> **drivePath:** 

> #### Return value
> 

### GetPartitionTable

> #### Return value
> 