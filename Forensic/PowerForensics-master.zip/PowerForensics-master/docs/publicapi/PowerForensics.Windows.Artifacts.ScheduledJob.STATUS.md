﻿


# Windows.Artifacts.ScheduledJob.STATUS

## Fields

### SCHED_S_TASK_READY

### SCHED_S_TASK_RUNNING

### SCHED_S_TASK_NOT_SCHEDULED
