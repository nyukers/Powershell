﻿


# FileSystems.Ntfs.ObjectId

## Fields

### ObjectIdGuid

### BirthVolumeId

### BirthObjectId

### BirthDomainId
