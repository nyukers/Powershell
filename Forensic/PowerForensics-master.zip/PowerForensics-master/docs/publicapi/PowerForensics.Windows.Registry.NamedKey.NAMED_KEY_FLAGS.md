﻿


# Windows.Registry.NamedKey.NAMED_KEY_FLAGS

## Fields

### VolatileKey

### MountPoint

### RootKey

### Immutable

### SymbolicLink

### NameIsASCII

### PredefinedHandle
