﻿


# Windows.Artifacts.MicrosoftOffice.FileMRU

## Fields

### User

### Path

### LastAccessedTime

## Methods


### Get(System.String)

> #### Parameters
> **hivePath:** 

> #### Return value
> 

### GetInstances(System.String)

> #### Parameters
> **volume:** 

> #### Return value
> 