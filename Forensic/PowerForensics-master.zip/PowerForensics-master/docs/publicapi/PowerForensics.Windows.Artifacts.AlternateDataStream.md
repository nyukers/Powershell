﻿


# Windows.Artifacts.AlternateDataStream

## Fields

### FullName

### Name

### StreamName

## Methods


### GetInstances(System.String)

> #### Parameters
> **volume:** 

> #### Return value
> 

### GetInstancesByPath(System.String)

> #### Parameters
> **path:** 

> #### Return value
> 