﻿


# Windows.Registry.Leaf

## Fields

### HashValue
