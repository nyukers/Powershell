﻿


# Windows.Artifacts.ShimDataBlock

## Fields

### LayerName
