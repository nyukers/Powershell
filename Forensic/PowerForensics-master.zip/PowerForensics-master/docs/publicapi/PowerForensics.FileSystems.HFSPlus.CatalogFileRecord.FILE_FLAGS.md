﻿


# FileSystems.HFSPlus.CatalogFileRecord.FILE_FLAGS

## Fields

### kHFSFileLockedBit

### kHFSFileLockedMask

### kHFSThreadExistsBit

### kHFSThreadExistsMask
