﻿


# FileSystems.Ntfs.IndexRoot

## Fields

### AttributeType

### CollationSortingRule

### IndexSize

### ClustersPerIndexRecord

### Flags

### Entries
