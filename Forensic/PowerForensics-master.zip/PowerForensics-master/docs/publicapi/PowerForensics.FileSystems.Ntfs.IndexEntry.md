﻿


# FileSystems.Ntfs.IndexEntry

## Fields

### RecordNumber
Low 6B: MFT record index, High 2B: MFT record sequence number
### Directory

### Filename

### FullName

## Methods


### Get(System.String)

> #### Parameters
> **path:** 

> #### Return value
> 

### GetInstances(System.String)

> #### Parameters
> **path:** 

> #### Return value
> 