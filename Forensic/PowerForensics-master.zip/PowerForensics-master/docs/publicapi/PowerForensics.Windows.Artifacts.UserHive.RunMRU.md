﻿


# Windows.Artifacts.UserHive.RunMRU

## Fields

### User

### ImagePath

## Methods


### Get(System.String)

> #### Parameters
> **hivePath:** 

> #### Return value
> 

### GetInstances(System.String)

> #### Parameters
> **volume:** 

> #### Return value
> 