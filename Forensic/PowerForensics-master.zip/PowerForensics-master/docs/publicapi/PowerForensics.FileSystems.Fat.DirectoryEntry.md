﻿


# FileSystems.Fat.DirectoryEntry
