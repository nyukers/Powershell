﻿


# Windows.Artifacts.ApplicationCompatibilityCache.Amcache
https://msdn.microsoft.com/en-us/library/cc248285.aspx
## Fields

### SequenceNumber

### RecordNumber

### ProductName

### CompanyName

### FileSize

### Description

### CompileTime

### ModifiedTimeUtc

### BornTimeUtc

### Path

### ModifiedTime2Utc

### Hash

## Methods


### GetInstances(System.String)

> #### Parameters
> **volume:** 

> #### Return value
> 

### GetInstancesByPath(System.String)

> #### Parameters
> **hivePath:** 

> #### Return value
> 