﻿


# Windows.Registry.SecurityDescriptor
