﻿


# Windows.Artifacts.ConsoleDataBlock.FONT

## Fields

### FF_DONTCARE

### FF_ROMAN

### FF_SWISS

### FF_MODERN

### FF_SCRIPT

### FF_DECORATIVE
