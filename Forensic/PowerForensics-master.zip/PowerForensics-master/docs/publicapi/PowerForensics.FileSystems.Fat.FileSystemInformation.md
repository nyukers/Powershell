﻿


# FileSystems.Fat.FileSystemInformation

## Fields

### FSI_Free_Count

### FSI_Nxt_Free

## Methods


### Get(System.String)

> #### Parameters
> **volume:** 

> #### Return value
> 