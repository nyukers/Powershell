﻿


# FileSystems.HFSPlus.BTree.PointerRecord

## Fields

### NodeNumber

## Methods


### GetChildNodes

> #### Return value
> 