﻿


# Windows.Artifacts.UserHive.LastVisitedMRU

## Fields

### User

### ImagePath

## Methods


### Get(System.String)

> #### Parameters
> **hivePath:** 

> #### Return value
> 