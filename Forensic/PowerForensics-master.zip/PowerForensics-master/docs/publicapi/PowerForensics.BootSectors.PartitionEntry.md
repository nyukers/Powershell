﻿


# BootSectors.PartitionEntry

## Fields

### Bootable

### SystemId

### StartSector

### EndSector
