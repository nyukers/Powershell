﻿


# Windows.Artifacts.SoftwareHive.NetworkList

## Fields

### WriteTimeUtc

### ProfileGuid

### Description

### Source

### DnsSuffix

### FirstNetwork

### DefaultGatewayMac

## Methods


### GetInstances(System.String)

> #### Parameters
> **volume:** 

> #### Return value
> 

### GetInstancesByPath(System.String)

> #### Parameters
> **hivePath:** 

> #### Return value
> 