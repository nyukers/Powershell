﻿


# Windows.Artifacts.IdList

## Fields

### ItemIdList
