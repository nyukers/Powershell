﻿


# FileSystems.Fat.FatVolumeBootRecord

## Fields

### FatType

### BS_OEMName

### BPB_NumberOfFATs

### BPB_RootEntryCount

### BPB_TotalSector16

### BPB_Media

### BPB_TotalSector32

### BPB_FatSize

### BPB_ExtFlags

### BPB_FileSystemVersion

### BPB_RootCluster

### BPB_FileSytemInfo

### BPB_BackupBootSector

### BS_DriveNumber

### BS_BootSignature

### BS_VolumeId

### BS_VolumeLabel

### BS_FileSystemType

### RootDirectorySector
