﻿


# Windows.Artifacts.UserHive.RecentDocs

## Fields

### User

### Path

### LastWriteTime

## Methods


### Get(System.String)

> #### Parameters
> **hivePath:** 

> #### Return value
> 

### GetInstances(System.String)

> #### Parameters
> **volume:** 

> #### Return value
> 