﻿


# FileSystems.Ntfs.AttributeList

## Fields

### AttributeReference
