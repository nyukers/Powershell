﻿


# Windows.Artifacts.KnownFolderDataBlock

## Fields

### KnownFolderId

### Offset
