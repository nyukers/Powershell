﻿


# Windows.Artifacts.ShellLink.HOTKEY_FLAGS

## Fields

### HOTKEYF_SHIFT

### HOTKEYF_CONTROL

### HOTKEYF_ALT

### K_0

### K_1

### K_2

### K_3

### K_4

### K_5

### K_6

### K_7

### K_8

### K_9

### K_A

### K_B

### K_C

### K_D

### K_E

### K_F

### K_G

### K_H

### K_I

### K_J

### K_K

### K_L

### K_M

### K_N

### K_O

### K_P

### K_Q

### K_R

### K_S

### K_T

### K_U

### K_V

### K_W

### K_X

### K_Y

### K_Z

### VK_F1

### VK_F2

### VK_F3

### VK_F4

### VK_F5

### VK_F6

### VK_F7

### VK_F8

### VK_F9

### VK_F10

### VK_F11

### VK_F12

### VK_F13

### VK_F14

### VK_F15

### VK_F16

### VK_F17

### VK_F18

### VK_F19

### VK_F20

### VK_F21

### VK_F22

### VK_F23

### VK_F24

### VK_NUMLOCK

### VK_SCROLL
