﻿


# Windows.Registry.LeafItem
