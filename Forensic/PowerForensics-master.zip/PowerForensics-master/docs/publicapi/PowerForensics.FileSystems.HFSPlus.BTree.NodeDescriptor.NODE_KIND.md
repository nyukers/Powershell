﻿


# FileSystems.HFSPlus.BTree.NodeDescriptor.NODE_KIND

## Fields

### kBTLeafNode

### kBTIndexNode

### kBTHeaderNode

### kBTMapNode
