﻿


# Windows.Artifacts.MicrosoftOffice.OutlookCatalog

## Fields

### User

### Path

## Methods


### Get(System.String)

> #### Parameters
> **hivePath:** 

> #### Return value
> 

### GetInstances(System.String)

> #### Parameters
> **volume:** 

> #### Return value
> 