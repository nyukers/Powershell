﻿


# BootSectors.GuidPartitionTableEntry
