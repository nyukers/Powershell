﻿


# Windows.Artifacts.PropertyStoreDataBlock

## Fields

### PropertyStore
