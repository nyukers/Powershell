﻿


# FileSystems.HFSPlus.CatalogFolderRecord

## Fields

### Valence

### CatalogNodeId

### CreateDate

### ContentModDate

### AttributeModDate

### AccessDate

### BackupDate

### Permissions

### UserInfo

### FinderInfo

### TextEncoding

### FolderCount
