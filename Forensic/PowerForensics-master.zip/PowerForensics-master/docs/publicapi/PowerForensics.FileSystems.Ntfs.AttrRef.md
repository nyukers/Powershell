﻿


# FileSystems.Ntfs.AttrRef

## Fields

### Name

### RecordNumber

### SequenceNumber

### NameString
