﻿


# FileSystems.Ntfs.NtfsVolumeBootRecord

## Fields

### BytesPerFileRecord

### BytesPerIndexBlock

### TotalSectors

### MftStartIndex

### MftMirrStartIndex

### VolumeSerialNumber
