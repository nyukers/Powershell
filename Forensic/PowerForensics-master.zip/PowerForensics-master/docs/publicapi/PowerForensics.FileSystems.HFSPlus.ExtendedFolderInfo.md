﻿


# FileSystems.HFSPlus.ExtendedFolderInfo

## Fields

### ScrollPosition

### ExtendedFinderFlags

### PutAwayFolderID
