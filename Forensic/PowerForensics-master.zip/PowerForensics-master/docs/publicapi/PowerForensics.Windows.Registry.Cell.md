﻿


# Windows.Registry.Cell

## Fields

### Allocated
