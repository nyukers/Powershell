﻿


# FileSystems.Ntfs.AttrDef.ATTR_DEF_ENTRY

## Fields

### INDEX

### ALWAYS_RESIDENT

### ALWAYS_NONRESIDENT
