﻿


# Windows.Artifacts.UserHive.WordWheelQuery

## Fields

### User

### SearchString

## Methods


### Get(System.String)

> #### Parameters
> **hivePath:** 

> #### Return value
> 

### GetInstances(System.String)

> #### Parameters
> **volume:** 

> #### Return value
> 