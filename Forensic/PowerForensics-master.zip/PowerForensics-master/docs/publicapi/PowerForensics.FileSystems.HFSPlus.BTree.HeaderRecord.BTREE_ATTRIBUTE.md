﻿


# FileSystems.HFSPlus.BTree.HeaderRecord.BTREE_ATTRIBUTE

## Fields

### kBTBadCloseMask

### kBTBigKeysMask

### kBTVariableIndexKeysMask
