﻿


# FileSystems.HFSPlus.ForkData

## Fields

### LogicalSize

### ClumpSize

### TotalBlocks

### Extents

## Methods


### GetContent

> #### Return value
> 

### GetSlack

> #### Return value
> 