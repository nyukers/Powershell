﻿


# Utilities.DD

## Methods


### Get(System.String,System.String,System.Int64,System.UInt32,System.UInt32)

> #### Parameters
> **inFile:** 

> **outFile:** 

> **offset:** 

> **blockSize:** 

> **count:** 


### Get(System.String,System.Int64,System.UInt32,System.UInt32)

> #### Parameters
> **inFile:** 

> **offset:** 

> **blockSize:** 

> **count:** 

> #### Return value
> 