﻿


# FileSystems.HFSPlus.FileInfo

## Fields

### FileType

### FileCreator

### FinderFlags

### Location

### ReservedField
