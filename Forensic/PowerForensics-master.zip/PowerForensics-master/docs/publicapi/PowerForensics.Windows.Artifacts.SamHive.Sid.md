﻿


# Windows.Artifacts.SamHive.Sid

## Methods


### Get(System.String)

> #### Parameters
> **volume:** 

> #### Return value
> 

### GetByPath(System.String)

> #### Parameters
> **hivePath:** 

> #### Return value
> 