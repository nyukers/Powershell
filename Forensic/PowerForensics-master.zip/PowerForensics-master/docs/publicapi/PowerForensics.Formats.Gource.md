﻿


# Formats.Gource

## Methods


### Get(PowerForensics.Formats.ForensicTimeline)

> #### Parameters
> **input:** 

> #### Return value
> 

### GetInstances(PowerForensics.Formats.ForensicTimeline[])

> #### Parameters
> **input:** 

> #### Return value
> 