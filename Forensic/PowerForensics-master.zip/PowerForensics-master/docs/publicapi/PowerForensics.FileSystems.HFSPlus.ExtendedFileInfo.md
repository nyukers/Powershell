﻿


# FileSystems.HFSPlus.ExtendedFileInfo

## Fields

### ExtendedFinderFlags

### PutAwayFolderID
