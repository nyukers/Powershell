﻿


# FileSystems.Ntfs.UsnJrnlInformation

## Fields

### MaxSize

### AllocationDelta

### UsnId

### LowestUsn

## Methods


### Get(System.String)

> #### Parameters
> **volume:** 

> #### Return value
> 

### GetByPath(System.String)

> #### Parameters
> **path:** 

> #### Return value
> 

### GetBytes(System.String)

> #### Parameters
> **volume:** 

> #### Return value
> 

### GetBytesByPath(System.String)

> #### Parameters
> **path:** 

> #### Return value
> 