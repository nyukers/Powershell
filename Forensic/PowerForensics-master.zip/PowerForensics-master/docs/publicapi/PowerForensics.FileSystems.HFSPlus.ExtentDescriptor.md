﻿


# FileSystems.HFSPlus.ExtentDescriptor

## Fields

### StartBlock

### BlockCount

## Methods


### GetContent

> #### Return value
> 