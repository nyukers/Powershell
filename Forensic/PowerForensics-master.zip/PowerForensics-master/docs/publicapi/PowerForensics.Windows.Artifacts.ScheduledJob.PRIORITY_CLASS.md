﻿


# Windows.Artifacts.ScheduledJob.PRIORITY_CLASS

## Fields

### NORMAL

### IDLE

### HIGH

### REALTIME
