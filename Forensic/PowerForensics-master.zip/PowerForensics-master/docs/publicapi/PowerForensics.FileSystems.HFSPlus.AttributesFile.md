﻿


# FileSystems.HFSPlus.AttributesFile

## Methods


### GetContent(System.String)
Returns the content of the HFS+ Attributes File.
> #### Parameters
> **volumeName:** 

> #### Return value
> 

### GetHeaderNode(System.String)

> #### Parameters
> **volumeName:** 

> #### Return value
> 

### GetNode(System.String,System.UInt32)

> #### Parameters
> **volumeName:** 

> **nodeNumber:** 

> #### Return value
> 

### GetNodeBytes(System.String,System.UInt32)

> #### Parameters
> **volumeName:** 

> **nodeNumber:** 

> #### Return value
> 