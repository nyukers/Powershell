﻿


# Windows.Artifacts.CommonNetworkRelativeLink.COMMON_NETWORK_RELATIVE_LINK_FLAGS

## Fields

### ValidDevice

### ValidNetType
