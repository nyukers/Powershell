﻿


# Windows.Registry.OffsetRecord

## Fields

### RelativeOffset

### Hash
