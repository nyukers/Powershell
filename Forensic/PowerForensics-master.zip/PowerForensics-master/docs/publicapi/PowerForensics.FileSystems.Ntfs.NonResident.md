﻿


# FileSystems.Ntfs.NonResident

## Fields

### AllocatedSize

### RealSize

### InitializedSize

### DataRun

## Methods


### GetBytes

> #### Return value
> 

### GetBytesTest

> #### Return value
> 

### GetSlack

> #### Return value
> 