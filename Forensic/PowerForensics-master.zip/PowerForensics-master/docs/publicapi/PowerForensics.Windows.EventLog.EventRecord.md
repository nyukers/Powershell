﻿


# Windows.EventLog.EventRecord

## Fields

### LogPath

### EventRecordId

### WriteTime

### EventData

## Methods


### GetInstances(System.String)

> #### Parameters
> **volume:** 

> #### Return value
> 

### Get(System.String)

> #### Parameters
> **path:** 

> #### Return value
> 

### ToString

> #### Return value
> 