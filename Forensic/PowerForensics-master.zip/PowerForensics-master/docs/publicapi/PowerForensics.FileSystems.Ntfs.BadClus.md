﻿


# FileSystems.Ntfs.BadClus

## Fields

### Cluster

### Bad
