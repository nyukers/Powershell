﻿


# Windows.EventLog.BinaryXml.VALUE_TYPE

## Fields

### NullType

### StringType

### AnsiStringType

### Int8Type

### UInt8Type

### Int16Type

### UInt16Type

### Int32Type

### UInt32Type

### Int64Type

### UInt64Type

### Real32Type

### Real64Type

### BoolType

### BinaryType

### GuidType

### SizeTType

### FileTimeType

### SysTimeType

### SidType

### HexInt32Type

### HexInt64Type

### EvtHandle

### BinXmlType

### EvtXml

### StringType_Array

### AnsiStringType_Array

### Int8Type_Array

### UInt8Type_Array

### Int16Type_Array

### UInt16Type_Array

### Int32Type_Array

### UInt32Type_Array

### Int64Type_Array

### UInt64Type_Array

### Real32Type_Array

### Real64Type_Array

### BoolType_Array

### BinaryType_Array

### GuidType_Array

### SizeTType_Array

### FileTimeType_Array

### SysTimeType_Array

### SidType_Array

### HexInt32Type_Array

### HexInt64Type_Array
