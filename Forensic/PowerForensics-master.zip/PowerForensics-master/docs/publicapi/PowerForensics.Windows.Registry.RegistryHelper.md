﻿


# Windows.Registry.RegistryHelper

## Methods


### GetHiveBytes(System.String)

> #### Parameters
> **path:** 

> #### Return value
> 

### GetRootKey(System.String)

> #### Parameters
> **path:** 

> #### Return value
> 