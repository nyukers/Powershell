﻿


# FileSystems.HFSPlus.BSDInfo.OWNER_FLAGS

## Fields

### UF_NODUMP

### UF_IMMUTABLE

### UF_APPEND

### UF_OPAQUE
