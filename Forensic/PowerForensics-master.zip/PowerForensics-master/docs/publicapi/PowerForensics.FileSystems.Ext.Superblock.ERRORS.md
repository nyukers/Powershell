﻿


# FileSystems.Ext.Superblock.ERRORS

## Fields

### Continue

### RemountReadOnly

### Panic
