﻿


# Windows.Artifacts.SamHive.UserDetail

## Fields

### LastLogon

### PasswordLastSet

### AccountExpires

### LastIncorrectPassword

### RelativeIdentifier

### AccountActive

### PasswordRequired

### CountryCode

### InvalidPasswordCount

### LogonCount

## Methods


### Get

> #### Return value
> 