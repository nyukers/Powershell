﻿


# Windows.Registry.SecurityDescriptor.SECURITY_KEY_CONTROLS

## Fields

### SeOwnerDefaulted

### SeGroupDefaulted

### SeDaclPresent

### SeDaclDefaulted

### SeSaclPresent

### SeSaclDefaulted

### SeDaclAutoInheritReq

### SeSaclAutoInheritReq

### SeDaclAutoInherited

### SeSaclAutoInherited

### SeDaclProtected

### SeSaclProtected

### SeRmControlValid

### SeSelfRelative
