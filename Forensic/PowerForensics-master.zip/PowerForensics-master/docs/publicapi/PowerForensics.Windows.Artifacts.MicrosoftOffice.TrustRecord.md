﻿


# Windows.Artifacts.MicrosoftOffice.TrustRecord

## Fields

### User

### Path

### TrustTime

## Methods


### Get(System.String)

> #### Parameters
> **hivePath:** 

> #### Return value
> 

### GetInstances(System.String)

> #### Parameters
> **volume:** 

> #### Return value
> 