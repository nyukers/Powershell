﻿


# Windows.Artifacts.EnvironmentVariableDataBlock

## Fields

### TargetAnsi

### TargetUnicode
