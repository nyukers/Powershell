﻿


# FileSystems.VolumeBootRecord.MEDIA_DESCRIPTOR

## Fields

### FloppyDisk

### HardDriveDisk
