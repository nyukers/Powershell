﻿


# Utilities.Compression.Xpress

## Methods


### DecompressBuffer(System.Byte[],System.UInt32,System.UInt32)

> #### Parameters
> **inputBuffer:** 

> **outputSize:** 

> **inputConsumed:** 

> #### Return value
> 

### DecompressBufferLZ77(System.Byte[],System.UInt32,System.UInt32)

> #### Parameters
> **inputBuffer:** 

> **outputSize:** 

> **inputConsumed:** 

> #### Return value
> 