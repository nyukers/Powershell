﻿


# FileSystems.Ext.Superblock.REVISION_LEVEL

## Fields

### Originalformat

### v2formatwithdynamicinodesizes
