﻿


# Windows.Artifacts.ScheduledJob
https://msdn.microsoft.com/en-us/library/cc248285.aspx