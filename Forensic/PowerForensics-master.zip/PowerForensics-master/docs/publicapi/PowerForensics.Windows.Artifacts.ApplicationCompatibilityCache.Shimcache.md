﻿


# Windows.Artifacts.ApplicationCompatibilityCache.Shimcache

## Fields

### Path

### LastModifiedTime

### FileSize

### LastUpdateTime

## Methods


### GetInstances(System.String)

> #### Parameters
> **volume:** 

> #### Return value
> 

### GetInstancesByPath(System.String)

> #### Parameters
> **hivePath:** 

> #### Return value
> 