﻿


# FileSystems.FileSystemEntry

## Methods


### Get(System.String)

> #### Parameters
> **path:** 

> #### Return value
> 

### GetInstances(System.String)

> #### Parameters
> **volume:** 

> #### Return value
> 