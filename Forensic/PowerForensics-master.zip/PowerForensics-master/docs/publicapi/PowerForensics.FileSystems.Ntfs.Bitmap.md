﻿


# FileSystems.Ntfs.Bitmap

## Fields

### Cluster

### InUse

## Methods


### Get(System.String,System.Int64)

> #### Parameters
> **volume:** 

> **cluster:** 

> #### Return value
> 

### GetByPath(System.String,System.Int64)

> #### Parameters
> **path:** 

> **cluster:** 

> #### Return value
> 

### GetInstancesByPath(System.String)

> #### Parameters
> **path:** 

> #### Return value
> 

### GetInstances(System.String)

> #### Parameters
> **volume:** 

> #### Return value
> 