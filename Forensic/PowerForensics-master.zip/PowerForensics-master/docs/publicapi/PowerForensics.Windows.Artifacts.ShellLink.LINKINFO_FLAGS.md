﻿


# Windows.Artifacts.ShellLink.LINKINFO_FLAGS

## Fields

### VolumeIDAndLocalBasePath

### CommonNetworkRelativeLinkAndPathSuffix
