﻿


# FileSystems.Ntfs.ATTR_FILENAME_FLAG

## Fields

### READONLY

### HIDDEN

### SYSTEM

### ARCHIVE

### DEVICE

### NORMAL

### TEMP

### SPARSE

### REPARSE

### COMPRESSED

### OFFLINE

### NCI

### ENCRYPTED

### DIRECTORY

### INDEXVIEW
