﻿


# Windows.Artifacts.ShellLink.LINK_FLAGS

## Fields

### HasLinkTargetIdList

### HasLinkInfo

### HasName

### HasRelativePath

### HasWorkingDir

### HasArguments

### HasIconLocation

### IsUnicode

### ForceNoLinkInfo

### HasExpString

### RunInSeparateProcess

### Unused1

### HasDarwinId

### RunAsUser

### HasExpIcon

### NoPidlAlias

### Unused2

### RunWithShimLayer

### ForceNoLinkTrack

### EnableTargetMetadata

### DisableLinkPathTracking

### DisableKnownFolderTracking

### DisableKnownFolderAlias

### AllowLinkToLink

### UnaliasOnSave

### PreferEnvironmentPath

### KeepLocalIdListForUncTarget
