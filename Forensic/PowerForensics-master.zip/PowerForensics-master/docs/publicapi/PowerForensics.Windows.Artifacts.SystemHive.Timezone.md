﻿


# Windows.Artifacts.SystemHive.Timezone

## Fields

### RegistryTimezone

## Methods


### Get(System.String)

> #### Parameters
> **volume:** 

> #### Return value
> 

### GetByPath(System.String)

> #### Parameters
> **hivePath:** 

> #### Return value
> 