﻿


# FileSystems.HFSPlus.ExtentsOverflowRecord.FORK_TYPE

## Fields

### Data

### Resource
