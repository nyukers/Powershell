﻿


# Helper.FILE_SYSTEM_TYPE

## Fields

### EXFAT

### FAT

### NTFS

### SOMETHING_ELSE
