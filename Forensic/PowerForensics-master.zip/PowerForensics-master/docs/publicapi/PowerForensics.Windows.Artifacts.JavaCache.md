﻿


# Windows.Artifacts.JavaCache

## Fields

### LastModified

### ExpirationDate

### ValidationTime

### Signed

### Version

### Url

### Namespace

### CodebaseIp

### HttpHeaders

## Methods


### GetInstances(System.String)

> #### Parameters
> **volume:** 

> #### Return value
> 

### Get(System.String)

> #### Parameters
> **path:** 

> #### Return value
> 

### 

> #### Parameters
> **bytes:** 

> #### Return value
> 