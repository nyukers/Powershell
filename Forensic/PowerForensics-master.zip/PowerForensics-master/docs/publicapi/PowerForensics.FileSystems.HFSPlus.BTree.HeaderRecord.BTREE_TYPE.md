﻿


# FileSystems.HFSPlus.BTree.HeaderRecord.BTREE_TYPE

## Fields

### kHFSBTreeType

### kUserBTreeType

### kReservedBTreeType
