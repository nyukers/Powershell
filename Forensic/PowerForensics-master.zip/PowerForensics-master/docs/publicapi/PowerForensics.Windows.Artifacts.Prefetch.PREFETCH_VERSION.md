﻿


# Windows.Artifacts.Prefetch.PREFETCH_VERSION

## Fields

### WINDOWS_8

### WINDOWS_7

### WINDOWS_XP
