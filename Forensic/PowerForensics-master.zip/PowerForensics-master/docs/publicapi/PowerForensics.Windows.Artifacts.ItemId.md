﻿


# Windows.Artifacts.ItemId

## Fields

### Data
