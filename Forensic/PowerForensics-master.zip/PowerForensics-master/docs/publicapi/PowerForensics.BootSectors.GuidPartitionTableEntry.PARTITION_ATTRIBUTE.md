﻿


# BootSectors.GuidPartitionTableEntry.PARTITION_ATTRIBUTE

## Fields

### RequirePartition

### NoBlockIOProtocol

### LegacyBIOSBootable
