﻿


# Windows.Artifacts.ConsoleFeDataBlock

## Fields

### CodePage
