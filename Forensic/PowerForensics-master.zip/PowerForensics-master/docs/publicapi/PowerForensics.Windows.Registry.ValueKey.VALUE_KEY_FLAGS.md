﻿


# Windows.Registry.ValueKey.VALUE_KEY_FLAGS

## Fields

### NameIsUnicode

### NameIsAscii
