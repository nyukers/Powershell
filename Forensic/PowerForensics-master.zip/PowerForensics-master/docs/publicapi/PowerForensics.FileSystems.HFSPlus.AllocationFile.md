﻿


# FileSystems.HFSPlus.AllocationFile

## Methods


### GetContent(System.String)
Returns the Contents of the HFS+ Allocation File.
> #### Parameters
> **volumeName:** 

> #### Return value
> 

### IsAllocationBlockUsed(System.String,System.UInt32)

> #### Parameters
> **volumeName:** 

> **blockNumber:** 

> #### Return value
> 