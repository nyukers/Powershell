﻿


# FileSystems.Ext.Superblock.CHECKSUM_TYPE

## Fields

### crc32c
