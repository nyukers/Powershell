﻿


# FileSystems.HFSPlus.BTree.DataRecord.RECORD_TYPE

## Fields

### kHFSPlusFolderRecord

### kHFSPlusFileRecord

### kHFSPlusFolderThreadRecord

### kHFSPlusFileThreadRecord
