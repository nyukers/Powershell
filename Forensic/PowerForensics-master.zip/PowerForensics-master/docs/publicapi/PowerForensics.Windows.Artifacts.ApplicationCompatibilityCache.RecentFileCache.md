﻿


# Windows.Artifacts.ApplicationCompatibilityCache.RecentFileCache

## Methods


### GetInstances(System.String)

> #### Parameters
> **volume:** 

> #### Return value
> 

### GetInstancesByPath(System.String)

> #### Parameters
> **path:** 

> #### Return value
> 