﻿


# FileSystems.Ntfs.StandardInformation.ATTR_STDINFO_PERMISSION

## Fields

### READONLY

### HIDDEN

### SYSTEM

### ARCHIVE

### DEVICE

### NORMAL

### TEMP

### SPARSE

### REPARSE

### COMPRESSED

### OFFLINE

### NCI

### ENCRYPTED
