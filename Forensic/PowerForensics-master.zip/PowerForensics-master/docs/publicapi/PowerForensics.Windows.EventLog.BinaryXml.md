﻿


# Windows.EventLog.BinaryXml
