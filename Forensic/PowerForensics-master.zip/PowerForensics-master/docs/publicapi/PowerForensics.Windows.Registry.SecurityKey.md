﻿


# Windows.Registry.SecurityKey

## Fields

### ReferenceCount

### Descriptor
