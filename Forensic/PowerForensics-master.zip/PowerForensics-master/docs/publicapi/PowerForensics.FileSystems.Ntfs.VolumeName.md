﻿


# FileSystems.Ntfs.VolumeName

## Fields

### VolumeNameString

## Methods


### Get(System.String)

> #### Parameters
> **volume:** 

> #### Return value
> 

### GetByPath(System.String)

> #### Parameters
> **path:** 

> #### Return value
> 