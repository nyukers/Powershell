﻿


# FileSystems.Ntfs.MasterFileTable

## Methods


### GetBytes(System.String)

> #### Parameters
> **volume:** 

> #### Return value
> 

### GetSlack(System.String)

> #### Parameters
> **volume:** 

> #### Return value
> 

### GetSlackByPath(System.String)

> #### Parameters
> **path:** 

> #### Return value
> 