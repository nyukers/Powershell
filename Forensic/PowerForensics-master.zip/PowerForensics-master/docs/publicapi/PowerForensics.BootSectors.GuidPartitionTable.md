﻿


# BootSectors.GuidPartitionTable

## Fields

### Revision

### HeaderSize

### MyLBA

### AlternateLBA

### FirstUsableLBA

### LastUsableLBA

### DiskGuid

### PartitionEntryLBA

### NumberOfPartitionEntries

### SizeOfPartitionEntry

### PartitionTable

## Methods


### Get(System.String)

> #### Parameters
> **devicePath:** 

> #### Return value
> 

### GetBytes(System.String)

> #### Parameters
> **devicePath:** 

> #### Return value
> 

### GetPartitionTable

> #### Return value
> 