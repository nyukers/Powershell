﻿


# Windows.EventLog.BinXmlValueText

## Fields

### ValueToken

### ValueType

### ValueData
