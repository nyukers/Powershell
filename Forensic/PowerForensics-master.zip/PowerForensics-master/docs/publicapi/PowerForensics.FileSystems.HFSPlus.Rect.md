﻿


# FileSystems.HFSPlus.Rect

## Fields

### Top

### Left

### Bottom

### Right
