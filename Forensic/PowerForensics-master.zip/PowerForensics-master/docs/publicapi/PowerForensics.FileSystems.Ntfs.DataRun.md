﻿


# FileSystems.Ntfs.DataRun

## Fields

### StartCluster

### ClusterLength

### Sparse

## Methods


### GetBytes

> #### Return value
> 