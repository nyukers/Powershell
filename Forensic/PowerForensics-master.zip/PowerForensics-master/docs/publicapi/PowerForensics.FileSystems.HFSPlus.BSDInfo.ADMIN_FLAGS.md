﻿


# FileSystems.HFSPlus.BSDInfo.ADMIN_FLAGS

## Fields

### SF_ARCHIVED

### SF_IMMUTABLE

### SF_APPEND
